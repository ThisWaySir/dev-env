Thank you for creating your personal page with MyStaticPage.com!

Installation 
============
Just upload the content of this archive to your web server and you are done.

License
=======
See license.txt
